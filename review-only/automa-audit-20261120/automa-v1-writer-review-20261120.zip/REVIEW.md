# Automa v1 writer integration — offline review only

**Not deployed, not deployable, and not live proof.** This archive contains an isolated dashboard candidate with its v1 route wired to a review whole-head writer, test-only fixtures, and a separate immutable postwrite verifier. No production files were changed and no remote operation was performed in packaging or testing.

The production writer adapter deliberately exports null; its test adapters are synthetic. Missing production authority/attestation, authenticated single-use receipt, durable atomic journal, no-retry transport, trusted immutable full-tree verification, and provider-specific protections and recovery remain substantive blockers. Tests do not prove real provider CAS, distributed durability, security, or live behavior. See `integration-original-REVIEW.md` and the detailed independent route review for further limitations.

`immutable-postverify/` is an independent research module with its own tests and README. It is **separate and not wired into** the dashboard route or writer. It needs a separately reviewed trusted reader and does not establish provider atomicity, authorization, or journal recovery.

`independent-route-review/REVIEW.md` is an unmodified prior review of an earlier supplied v1 snapshot, not a review of the integrated candidate in this archive. Its observation that no integrated app had been supplied reflects that earlier snapshot; it must not be read as a finding about the included integrated app. Its requirements and evidence limitations remain useful but have not all been independently verified here.

## Independent local rerun

Unmodified test files were copied to a new temporary workspace with an empty home, a fresh temporary directory, and a minimal environment. Node v20.19.2 and Python 3.14.4. No credentials or production configuration were supplied. The actual commands, run from their respective copied directories:

```
node --test actions-auditor.test.js privacy-regression.test.js route-integration.test.cjs writer-binding.test.cjs
node --test test.js
```

- The exact existing dashboard suite: 60 passed, 0 failed, 0 skipped; exit 0. Its original log and new rerun log are under `logs/`.
- Separate immutable verifier suite: 42 passed, 0 failed, 0 skipped; exit 0; rerun log under `logs/`.
- These are fixture-based offline tests. The dashboard suite includes a stalled local `127.0.0.1` HTTP server to test timeout behavior, **not a loopback mock Ollama server**, and does not run a real Ollama model. It uses mocked audit/provider and writer adapters. The Python producer dependency is included solely for a verdict-contract test. The immutable suite uses synthetic in-memory Git objects.
- The disposable workspace is filesystem/environment isolation, **not OS-enforced network isolation**. No live network operation was intentionally performed. These results do not meet the stronger OS-network-isolated black-box requirements in the prior route review.

The original integration review says the suite was not independently rerun; that was accurate when authored and is superseded only as to rerun status by the logs above, not by any broader validation claim. Credential-shaped strings in fixtures are synthetic; no credentials or git directories are included.

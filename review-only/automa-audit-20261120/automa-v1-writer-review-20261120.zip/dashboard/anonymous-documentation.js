'use strict';
// Anonymous input is hostile. This is a deliberately narrow content gate, not
// identity verification, a general secret scanner, or an isolated code test.
//
// Patches may target any eligible source or documentation file (not just
// README.md). Documentation files (.md/.txt) remain append-only plain text;
// source files (.js/.ts/.tsx/.jsx/.mjs/.cjs) may be edited freely within size
// limits, with safety gated downstream by the extended keyword scan, esbuild
// syntax check, and the AI auditor quorum in runPatchPipeline.
const MAX_FILE_BYTES = 32000, MAX_APPEND_BYTES = 1024, MAX_APPEND_LINES = 20;
function wellFormed(s) {
  for (let i = 0; i < s.length; i++) {
    const n = s.charCodeAt(i);
    if (n >= 0xd800 && n <= 0xdbff) {
      const next = s.charCodeAt(++i);
      if (!(next >= 0xdc00 && next <= 0xdfff)) return false;
    } else if (n >= 0xdc00 && n <= 0xdfff) return false;
  }
  return true;
}
function secrets(s) {
  return /(?:-----BEGIN [A-Z ]*PRIVATE KEY-----|\b(?:gh[opusr]_[A-Za-z0-9_]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9_-]{20,}|AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16})\b|\b(?:password|passwd|api[_ -]?key|access[_ -]?token|secret|authorization)\s*[:=]\s*['"]?[^\s'"<>]{8,})/i.test(s);
}
// Mirror app.js validatePatchPath so prevalidate is safe to call directly (the
// handler and pipeline also call validatePatchPath). Allows source and docs
// files; rejects traversal, dot-segments, vendored/build dirs, lockfiles, etc.
function isEligiblePath(filename) {
  return typeof filename === 'string' && filename.length <= 1024 &&
    /^[A-Za-z0-9_./-]+$/.test(filename) &&
    !filename.split('/').some(x => !x || x === '.' || x === '..' || x.startsWith('.')) &&
    !filename.split('/').some(x => ['node_modules', 'vendor', 'dist', 'build'].includes(x.toLowerCase())) &&
    /\.(?:ts|tsx|js|jsx|mjs|cjs|md|txt)$/i.test(filename) &&
    !/(?:^|\/)(?:package-lock|npm-shrinkwrap|yarn|pnpm-lock|dockerfile|makefile)(?:\.|$)/i.test(filename);
}
function prevalidate(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).sort().join(',') !== 'description,file,patch,reviewedSha') throw Error('Exactly file, patch, description and reviewedSha are required');
  if (!Object.values(body).every(x => typeof x === 'string' && wellFormed(x))) throw Error('String fields with valid Unicode required');
  if (!isEligiblePath(body.file)) throw Error('File path not eligible for anonymous editing');
  if (!/^[0-9a-f]{40}$/.test(body.reviewedSha)) throw Error('Reviewed GitHub blob SHA required');
  if (Buffer.byteLength(body.patch) > MAX_FILE_BYTES || body.patch.length < 5 || body.patch.includes('\0')) throw Error('Candidate exceeds limit or is invalid');
  if (Buffer.byteLength(body.description) > 160 || !/^[A-Za-z0-9 ,.;:!?()\-]*$/.test(body.description)) throw Error('Invalid description');
  if (secrets(body.patch) || secrets(body.description)) throw Error('Possible secret detected');
}
function validateDiff(original, candidate, filename) {
  if (typeof original !== 'string' || !wellFormed(original) || Buffer.byteLength(original) > MAX_FILE_BYTES) throw Error('Invalid baseline');
  if (typeof candidate !== 'string' || !wellFormed(candidate)) throw Error('Invalid Unicode');
  if (Buffer.byteLength(candidate) > MAX_FILE_BYTES) throw Error('Candidate exceeds file limit');
  if (secrets(candidate)) throw Error('Possible secret detected');
  // Documentation files remain append-only plain text: anonymous users may add
  // documentation, never rewrite or delete it.
  if (/\.(?:md|txt)$/i.test(filename || '')) {
    if (!original.endsWith('\n')) throw Error('Invalid baseline');
    if (!candidate.startsWith(original) || candidate === original) throw Error('Candidate must append to the entire baseline');
    const suffix = candidate.slice(original.length);
    const addedBytes = Buffer.byteLength(suffix);
    if (addedBytes > MAX_APPEND_BYTES) throw Error('Append exceeds 1024 bytes');
    const addedLines = suffix.split('\n').length - (suffix.endsWith('\n') ? 1 : 0);
    if (addedLines > MAX_APPEND_LINES) throw Error('Append exceeds 20 lines');
    if (!/^[A-Za-z0-9 \n.,;:!?()'"-]+$/.test(suffix) || /[A-Za-z][A-Za-z0-9]*\s*\([^)]*\)\s*;/.test(suffix)) throw Error('Append must be plain text');
    return { addedBytes, addedLines };
  }
  // Source files: any change within the file size limit. The extended keyword
  // scan (newly-introduced dangerous patterns), esbuild syntax check and AI
  // auditor quorum in runPatchPipeline gate safety for source edits.
  if (candidate === original) throw Error('Candidate must differ from the reviewed baseline');
  const bytes = Buffer.byteLength(candidate);
  const lines = candidate.split('\n').length - (candidate.endsWith('\n') ? 1 : 0);
  return { bytes, lines };
}
// Flat string-only JSON: reject duplicate (including escaped) keys and trailing data.
function parse(text) {
  let i = 0; const result = Object.create(null);
  const skip = () => { while (i < text.length && ' \t\r\n'.includes(text[i])) i++; };
  const token = /"(?:[^"\\\x00-\x1f]|\\(?:["\\/bfnrt]|u[0-9a-fA-F]{4}))*"/y;
  function string() { token.lastIndex = i; const m = token.exec(text); if (!m) throw Error('Invalid JSON'); i = token.lastIndex; const s = JSON.parse(m[0]); if (!wellFormed(s)) throw Error('Invalid Unicode'); return s; }
  skip(); if (text[i++] !== '{') throw Error('Invalid object'); skip();
  for (let n = 0; n < 4 && text[i] !== '}'; n++) {
    if (n) { if (text[i++] !== ',') throw Error('Invalid separator'); skip(); }
    const k = string(); skip(); if (!['file','patch','description','reviewedSha'].includes(k) || Object.hasOwn(result,k) || text[i++] !== ':') throw Error('Invalid or duplicate field');
    skip(); result[k] = string(); skip();
  }
  if (text[i++] !== '}') throw Error('Invalid object'); skip(); if (i !== text.length) throw Error('Trailing data');
  return result;
}
module.exports = {prevalidate, validateDiff, parse};

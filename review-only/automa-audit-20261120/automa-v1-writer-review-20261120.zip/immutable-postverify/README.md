# Offline immutable postwrite verifier (research component)

Not integrated, deployable, or a provider implementation. No network calls or production changes. This component models `deps.verifyCommit` required by `dashboard/whole-head-writer.prototype.js`. It is independent of v1 `app.js` and does not modify its votes, guards, routes, journal, or existing forensic verifier.

## Interface

```js
const { verifyImmutableCommit } = require('./immutable-postverify');
const verifyCommit = args => verifyImmutableCommit(args, trustedReader);
// args: { repository, filename, base, commit, mode, content, contentDigest }
// Returns Promise<boolean>; all errors and incomplete evidence => false.
```

The caller must supply `commit` as the exact OID returned by the mutation response after validating that response and operation identifier. It must also supply the independently authorized baseline and content digest, and preserve uncertain/journal reconciliation behavior when verification fails. This verifier does not establish that a mutation occurred, that the response belongs to a particular operation, that the branch still points to this commit, or that a provider implements any atomic CAS semantics. It does not read mutable HEAD. Verification failure after a write does not undo it or justify replay.

The repository is constrained to `Maka-opsol/Automa-bot`, paths use the prototype's restrictive syntax, and the only supported prior/new mode is `100644`; creation, deletion, no-op, symlink and executable writes fail closed. Content must be a well-formed JS Unicode string with its exact UTF-8 bytes; SHA-256 is checked both against input bytes and returned blob bytes, without normalizing CRLF.

## Reader contract and limits

`trustedReader.getObject(repository, oid)` returns one *complete raw Git object payload* (not JSON/tree listings, compressed bytes, or an object header):

```js
{ status: 200, repository, oid, type: 'commit'|'tree'|'blob',
  data: Buffer, complete: true, truncated: false, hasMore: false }
```

All requested IDs are immutable full lowercase 40-hex SHA-1 IDs. A successful adapter must obtain raw object payloads under the authenticated and correctly scoped repository, and must independently ensure correct status, complete bytes, no truncation/pagination, and correct object type before setting flags. It must reject partial or ambiguous API responses; invented completeness flags are not evidence. The code checks the response identity and recalculates each raw Git object's SHA-1 including the Git header, binding its content to the requested OID. Repository identity/membership is a **trusted adapter precondition**: a reader echo alone cannot establish where an object came from. Git SHA-1 collision resistance is also assumed; this is not a proof against chosen-prefix SHA-1 collision attacks. No claim is made that any particular GitHub API exposes this exact contract, complete raw trees, or supports atomic writes.

It reads both pinned commit objects, checks exactly one parent equal to base, recursively parses and checks both complete content-addressed tree structures, compares every directory presence and every leaf path/mode/OID, and permits only the requested existing file to change. Directory OIDs necessarily change along the target ancestry; directory presence/mode, and all descendant entries including empty directories, still participate in the comparison. The old and new target blob objects are individually retrieved and their Git hashes checked. Non-target blob contents are not retrieved: equality is by their tree OID and mode. Non-target gitlinks and symlinks may exist unchanged. Malformed trees, duplicate names, noncanonical ordering, invalid UTF-8 tree names, missing objects and evidence over conservative limits fail closed. Limits: 50,000 distinct object reads, 100,000 combined traversed entries, depth 128, and 32 MiB per object. Legitimate large repositories may therefore be unverifiable.

## Offline tests

Run `node --test test.js`. Synthetic in-memory Git objects only; includes nested trees, unchanged paths, unexpected files and empty directories, parents, invalid responses, truncation/pagination, blob tampering, digest/byte/CRLF mismatch, path/repository mismatch, malformed entries, symlink and executable changes. This is local model evidence, not provider or end-to-end validation. Integrating this requires a separately reviewed real reader, live-service behavior validation, audit/journal wiring, and race/uncertainty handling; do not deploy as-is.

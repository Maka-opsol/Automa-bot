# Automa adversarial offline integration harness — REVIEW ONLY

This directory is separate from all three source worktrees. No deployment, dispatch, production write or live credentials. Only synthetic data. **Not a deployable integration and not evidence that an actual production route is safe.** The available timing and privacy dashboard candidates are separate snapshots; the whole-head writer is an unwired prototype. We found no actual combined route in the supplied paths. Do not remove existing write hard stops on this evidence.

## What runs now

`node --test harness.test.cjs` uses the **exact source files** in the candidate directories, without copying or patching them: deadline producer's `audit.verdict` (not its full evaluator or Ollama call), privacy adapter `audit`, prototype writer `writeWholeHead`, and the privacy app's extracted strict JSON parser. A synthetic Actions transport sends the Python producer's synthetic verdict through the actual adapter; a local test-only JS bridge hands its returned aggregate result to the writer's injected synthetic authorizer. A synthetic provider implements the *assumed* expected-head check and tracks an immutable synthetic tree; a filesystem-exclusive reservation and state file models a journal. It does not simulate or demonstrate GitHub's semantics, or prove an authorization or journal design. No route is invoked.

Override exact module files with absolute paths `AUDITOR_PATH`, `APP_PATH`, `WRITER_PATH`, and producer directory with `PRODUCER_PATH`. The interface must remain compatible; incompatibility fails, not skips. E.g. use deadline dashboard in place of privacy dashboard:

```
AUDITOR_PATH=/absolute/path/to/deadline/dashboard/actions-auditor.js \
APP_PATH=/absolute/path/to/deadline/dashboard/app.js \
node --test harness.test.cjs
```

`results.log` and `deadline-results.log` are local test output, generated on synthetic fixtures. The latter replaces the privacy adapter with the deadline adapter; **these are two separate test runs, not a combined timing+privacy dashboard implementation**. Reviewers must independently verify sources and dependency versions. Tests exercise happy path, exact one-file/mode/parent postcondition, missing or unadmitted/privacy-denied candidate and missing file, incorrect blob/baseline/head/path/repository/branch/content, unauthorized/disabled, weak or duplicate vote sets, veto, nonce/run/attempt/actor/workflow mismatch, expired artifact, redirect allowlist, audit deadline, untrusted auth and mode, concurrent requests, unrelated same-target-blob head race, lost/malformed result, failed immutable verification, journal-finalization failure, restart replay, and sampled logs/journal/storage-token leak checks. A writer response failure after a successful synthetic provider write must remain unknown. `results.log` records the counts.

## Production-route suite when actual combined source exists

`route.test.cjs` specifies adversarial expectations on an actual dashboard submit route, including the separate pre-dispatch and post-audit/pre-write deadline boundaries. It **cannot be run meaningfully until an actual combined module and a thin adapter are supplied**. It deliberately fails if either path is missing, rather than silently skipping.

Run only in an independently enforced network-isolated, disposable OS container; built-in Node socket patches are defense in depth, NOT network containment, and do not stop child processes or native modules. Bind no real credentials. Supply paths:

```
INTEGRATED_PATH=/absolute/path/to/exact/combined/app.js \
ROUTE_ADAPTER=/absolute/path/to/thin-local-adapter.cjs \
node --test route.test.cjs
```

The adapter exports `async createFixture({integratedPath,scenario,baseline,initial,candidate,filename})`. It must **load the exact integratedPath and invoke the genuine production submission route and status/recovery paths** (not reimplement the pipeline), replace only external boundaries with fake Actions/GraphQL provider and durable journal, and return:

* `loadedSource`: exact resolved app filename;
* `submit({filename,content,baseline})`: wait for final observable route result; resolve `{outcome:'committed'|'unknown'|'rejected', commit?}`;
* `snapshot()`: independent fake-provider/journal observations `{head,parent,target,other,mode,changedPaths,writes,successfulWrites,dispatches,public,logs}`. Count `writes` as outbound mutation attempts even if rejected or ambiguous; `successfulWrites` as provider-applied candidate writes. Never derive observations from submitted result;
* `restart()`: tear down and recreate the actual app/process with the same fake durable provider and journal; do not clear unresolved reservations;
* `close()`: stop/cleanup all isolated fixtures.

Scenario strings are the test names in `route.test.cjs`. Fault injection occurs at external seams: use strict exact-content admission; three votes under distinct provider identities; run/nonce/workflow/attempt corruption; expired artifact; mocked clock advancement at both deadline boundaries; unrelated synthetic commit at `b` repeated 40 with target unchanged, other=`concurrent`; write accepted but response lost, malformed response, or journal-finalization failure; same-target concurrency. `unauthorized` and `bad-origin` must model the production route's actual auth/CSRF policy (do not invent a requirement where public admission is intentional). The latter may need policy-specific adaptation, but must never turn Origin into authentication. If the real candidate's API cannot provide these seams, implement a reviewed transport shim or non-network local process wiring; do not modify the source to make tests pass or bypass safeguards. Review adapter code against the exact sources and ensure it cannot fabricate results or assertions. The suite's contract/adapter has not been implemented or run against an integrated route.

## Critical limitations and follow-up

* The component bridge constructs a test-only authorizer; returned v1 audit votes are advisory, not an authenticated, single-use receipt bound to head/expiry/operation. The prototype writer has no independently enforced deadline. Post-audit expiry, route admission/auth, actual writer wiring and true single-use authorization are **not tested** by the passing component suite. Receipt and write deadline must be integrated and tested without weakening the strict three-vote or privacy gates.
* The producer's `verdict()` is invoked with synthetic votes; no evaluator inference, job, actual Ollama runtime, clock behavior or real GitHub Actions dispatch was exercised. One test checks expiry in the privacy or timing audit adapter's mocked transport; this is not proof of the 50-minute route budget or per-request aborts. Source timer uses wall clock per timing review.
* The synthetic file journal uses exclusive file creation and a persisted state but is not the production GitHub/shared journal, lacks distributed semantics, and `restart()` is a fresh adapter instance within the same process, not a power-loss or separate-host crash test. No durability or reconciliation proof. Transition writes are not separately fsynced.
* The fake provider assumes exact-head CAS; this **cannot establish** real GitHub atomicity, ABA behavior, branch protection/rulesets, permissions, file mode preservation or timeout behavior. True ABA is not caught by OID equality alone. Resolve provider assurance and unauthorized ref resets/deletion; independently test in a separately authorized disposable repo only.
* Tests use synthetic candidates and a narrow log/journal/storage check, not a complete privacy assessment. Admission denylist is not proof of no sensitive content; the public Actions channel is not a private transport. No secrets, academic/personal content or non-public patches should be dispatched to it.
* The helper uses JS `net`/HTTP monkeypatching and a tiny Python subprocess for trusted inspected producer verdict; this is not a security boundary. A future adapter can execute arbitrary code: inspect it first and use genuine OS network isolation with no credentials.

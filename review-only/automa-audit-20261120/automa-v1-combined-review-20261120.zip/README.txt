AUTOMA COMBINED REVIEW: OFFLINE ONLY; NOT DEPLOYABLE

The v1 timing and privacy dashboard changes are combined in v1/dashboard. The v1 producer is provided as evaluator source, tests, workflow, and git bundle. Independent reruns: dashboard 28/28; producer 17/17 with locally configured tokenizer; synthetic v1 producer + dashboard consumer + test-only authorization bridge + whole-head prototype 33/33. The writer is NOT wired into the v1 actual route. The test bridge invents a synthetic authorization receipt and provider; it is not a production integration. See v1/REVIEW.md and blackbox/README.md.

Separate alternative-v2.zip is an incompatible v2 experiment, not a replacement for the published v1 protocol, has an intentionally unavailable writer-dependency hard stop, and must not be deployed or used as a v1 patch. Its independent mocked suite passed 135/135.

No real Ollama, live dispatch, deployment, remote write or GitHub expected-head atomicity validation occurred. Privacy, genuine authorization, restart/recovery and transport timeout remain unresolved. The evaluator bundle preserves local git history; publishing requires review of pin and exact ancestry. The producer tests require a reconstructed git checkout and a local tokenizer, not included here.

To rerun the component test on unpacked files, set AUDITOR_PATH and APP_PATH to absolute paths of v1/dashboard/actions-auditor.js and app.js, WRITER_PATH to absolute path of writer/whole-head-writer.prototype.js, PRODUCER_PATH to absolute path of v1/producer/auditor, and run node --test blackbox/harness.test.cjs in a network-isolated environment. Test-only synthetic fixtures, not real credentials.

'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const {spawnSync, spawn} = require('node:child_process');
const {writeWholeHead} = require('./dashboard/whole-head-writer.prototype');
const crypto = require('node:crypto');
const sha = x => crypto.createHash('sha256').update(x).digest('hex');
function g(dir,...args) { const r=spawnSync('git',args,{cwd:dir,encoding:'utf8'}); if(r.status!==0) throw Error(r.stderr); return r.stdout.trim(); }
function repo() {
 const d=fs.mkdtempSync(path.join(os.tmpdir(),'cas-test-')); g(d,'init','-q','-b','main'); g(d,'config','user.name','Test'); g(d,'config','user.email','test@example.invalid');
 fs.writeFileSync(path.join(d,'target.js'),'base'); fs.writeFileSync(path.join(d,'other.txt'),'a'); g(d,'add','.'); g(d,'commit','-qm','A');
 const A=g(d,'rev-parse','HEAD'); fs.writeFileSync(path.join(d,'other.txt'),'b'); g(d,'add','.'); g(d,'commit','-qm','B');
 const B=g(d,'rev-parse','HEAD'); return {d,A,B,clean(){fs.rmSync(d,{recursive:true,force:true});}};
}
// Build a commit with the exact parent in a disposable index, without touching ref.
function candidate(r,base,content='new') {
 fs.writeFileSync(path.join(r.d,'payload'),content); const data=g(r.d,'hash-object','-w','payload');
 const index=path.join(r.d,'idx-'+crypto.randomBytes(4).toString('hex'));
 function gi(...args){const x=spawnSync('git',args,{cwd:r.d,encoding:'utf8',env:{...process.env,GIT_INDEX_FILE:index}});if(x.status!==0)throw Error(x.stderr);return x.stdout.trim()}
 try {gi('read-tree',base); gi('update-index','--cacheinfo',`100644,${data},target.js`); const tree=gi('write-tree'); return gi('commit-tree',tree,'-p',base,'-m','candidate');} finally {try{fs.unlinkSync(index)}catch{}}
}
function cas(r,next,expected) { return spawnSync('git',['update-ref','refs/heads/main',next,expected],{cwd:r.d,encoding:'utf8'}); }
function head(r){ try{return g(r.d,'rev-parse','--verify','refs/heads/main')}catch{return null;} }
function advance(r,file='other.txt',v='advance'){ fs.writeFileSync(path.join(r.d,file),v); g(r.d,'add',file); g(r.d,'commit','-qm','advance'); return head(r); }
function input(base){return {repository:'Maka-opsol/Automa-bot',branch:'main',filename:'target.js',content:'new',message:'Patch',base,mode:'100644',audit:{ok:true}};}
function harness(r,opts={}) {
 let lock=false, sends=0, uncertain=0, completed=0, sent;
 const journal={ async reserve(i){if(lock)return {status:'duplicate'}; lock=true; return {status:'reserved',i};}, async uncertain(){uncertain++}, async committed(){completed++;return !opts.journalFail} };
 const deps={journal, async authorize(a,ctx){return a.ok && ctx.contentDigest===sha('new') && !opts.noAuth;}, async enabled(){return !opts.disabled},
 async sendOnce(req){sends++; sent=req; if(opts.before) await opts.before(req); const v=req.variables.input; const next=candidate(r,v.expectedHeadOid,Buffer.from(v.fileChanges.additions[0].contents,'base64').toString());
  const updated=cas(r,next,v.expectedHeadOid); if(updated.status!==0) return {status:200,errors:[{message:'stale'}]};
  if(opts.loseResponse) throw Error('response lost');
  let out={status:200,data:{createCommitOnBranch:{clientMutationId:v.clientMutationId,commit:{oid:next,parents:{totalCount:1,nodes:[{oid:v.expectedHeadOid}]}}}}};
  return opts.response ? opts.response(out) : out;
 }, async verifyCommit(x){if(opts.badVerify)return false; const parent=g(r.d,'rev-parse',x.commit+'^'); const actual=g(r.d,'show',x.commit+':'+x.filename); const changed=g(r.d,'diff-tree','--no-commit-id','--name-only','-r',parent,x.commit).split('\n');
 return parent===x.base && actual===x.content && changed.length===1 && changed[0]===x.filename && g(r.d,'ls-tree',x.commit,x.filename).startsWith(x.mode+' blob '); }};
 return {deps,stats:()=>({lock,sends,uncertain,completed,sent})};
}
test('normal commit sends expected OID and verifies only target change',async()=>{const r=repo();try{const h=harness(r), c=await writeWholeHead(input(r.B),h.deps);assert.equal(head(r),c);assert.equal(h.stats().sent.variables.input.expectedHeadOid,r.B);assert.equal(g(r.d,'rev-parse',c+'^'),r.B);assert.equal(h.stats().completed,1)}finally{r.clean()}});
test('unrelated concurrent change rejected despite same target blob',async()=>{const r=repo();try{const h=harness(r,{before:()=>advance(r)});await assert.rejects(writeWholeHead(input(r.B),h.deps),/unknown/);assert.notEqual(head(r),r.B);assert.equal(g(r.d,'show','HEAD:target.js'),'base');assert.equal(h.stats().uncertain,1)}finally{r.clean()}});
test('target changed and restored does not authorize old whole head',async()=>{const r=repo();try{advance(r,'target.js','changed');advance(r,'target.js','base');const h=harness(r);await assert.rejects(writeWholeHead(input(r.B),h.deps),/unknown/);assert.equal(h.stats().sends,1)}finally{r.clean()}});
test('rewound ancestor is a fast-forward to candidate but is not expected HEAD',()=>{const r=repo();try{const c=candidate(r,r.B);g(r.d,'update-ref','refs/heads/main',r.A);assert.equal(spawnSync('git',['merge-base','--is-ancestor',r.A,c],{cwd:r.d}).status,0);assert.notEqual(cas(r,c,r.B).status,0);assert.equal(head(r),r.A)}finally{r.clean()}});
test('deleted branch is not silently recreated',async()=>{const r=repo();try{g(r.d,'update-ref','-d','refs/heads/main');const h=harness(r);await assert.rejects(writeWholeHead(input(r.B),h.deps),/unknown/);assert.equal(head(r),null)}finally{r.clean()}});
test('deleted and recreated different branch rejected',async()=>{const r=repo();try{g(r.d,'update-ref','-d','refs/heads/main');g(r.d,'update-ref','refs/heads/main',r.A);const h=harness(r);await assert.rejects(writeWholeHead(input(r.B),h.deps),/unknown/);assert.equal(head(r),r.A)}finally{r.clean()}});
test('true ABA cannot be detected by OID-only CAS',async()=>{const r=repo();try{advance(r);g(r.d,'update-ref','refs/heads/main',r.B);const h=harness(r);const c=await writeWholeHead(input(r.B),h.deps);assert.equal(head(r),c)}finally{r.clean()}});
test('real concurrent update-ref CAS has exactly one winner',async()=>{const r=repo();try{const c1=candidate(r,r.B,'one'),c2=candidate(r,r.B,'two');function run(c){return new Promise(resolve=>{const p=spawn('git',['update-ref','refs/heads/main',c,r.B],{cwd:r.d});p.on('close',resolve);});}const codes=await Promise.all([run(c1),run(c2)]);assert.equal(codes.filter(x=>x===0).length,1);assert.ok([c1,c2].includes(head(r)))}finally{r.clean()}});
test('lost reply after actual commit is unknown and replay blocked',async()=>{const r=repo();try{const h=harness(r,{loseResponse:true});await assert.rejects(writeWholeHead(input(r.B),h.deps),/unknown/);assert.notEqual(head(r),r.B);await assert.rejects(writeWholeHead(input(r.B),h.deps),/reservation/);assert.equal(h.stats().sends,1)}finally{r.clean()}});
for(const [name,opt] of [['missing payload',{response:()=>({status:200})}],['partial data and errors',{response:o=>({...o,errors:[{message:'x'}]})}],['wrong status',{response:o=>({...o,status:500})}],['wrong mutation id',{response:o=>{o.data.createCommitOnBranch.clientMutationId='bad';return o}}],['wrong parent',{response:o=>{o.data.createCommitOnBranch.commit.parents.nodes[0].oid='f'.repeat(40);return o}}],['extra parent',{response:o=>{o.data.createCommitOnBranch.commit.parents.totalCount=2;return o}}],['bad commit oid',{response:o=>{o.data.createCommitOnBranch.commit.oid='bad';return o}}],['verification failure',{badVerify:true}],['journal completion failure',{journalFail:true}]]) {
 test(name+' holds reservation and reports unknown',async()=>{const r=repo();try{const h=harness(r,opt);await assert.rejects(writeWholeHead(input(r.B),h.deps),/unknown/);assert.equal(h.stats().uncertain,1);assert.equal(h.stats().lock,true);assert.equal(h.stats().sends,1)}finally{r.clean()}});
}
for(const [name,mutate] of [['wrong repo',i=>i.repository='Maka-opsol/other'],['wrong branch',i=>i.branch='review'],['bad baseline',i=>i.base='bad'],['symlink mode',i=>i.mode='120000'],['executable mode',i=>i.mode='100755'],['dot path',i=>i.filename='../target.js'],['missing audit',i=>i.audit=null]]){
 test(name+' rejected before reservation and send',async()=>{const r=repo();try{const h=harness(r),i=input(r.B);mutate(i);await assert.rejects(writeWholeHead(i,h.deps),e=>e.notSent===true);assert.equal(h.stats().lock,false);assert.equal(h.stats().sends,0)}finally{r.clean()}});
}
test('failed audit never reserves or sends',async()=>{const r=repo();try{const h=harness(r,{noAuth:true});await assert.rejects(writeWholeHead(input(r.B),h.deps),e=>e.notSent===true);assert.equal(h.stats().sends,0);assert.equal(h.stats().lock,false)}finally{r.clean()}});
test('disabled write never reserves or sends',async()=>{const r=repo();try{const h=harness(r,{disabled:true});await assert.rejects(writeWholeHead(input(r.B),h.deps),e=>e.notSent===true);assert.equal(h.stats().sends,0);assert.equal(h.stats().lock,false)}finally{r.clean()}});
test('switch revoked after reservation holds lock and sends nothing',async()=>{const r=repo();try{const h=harness(r);let n=0;h.deps.enabled=async()=>++n===1;await assert.rejects(writeWholeHead(input(r.B),h.deps),e=>e.notSent===true);assert.equal(h.stats().sends,0);assert.equal(h.stats().lock,true)}finally{r.clean()}});

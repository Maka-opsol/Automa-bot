'use strict';
// OFFLINE RESEARCH PROTOTYPE. Not imported by app.js. GitHub CAS semantics,
// authenticated audit receipts, journal integration and mode preservation need
// independent verification before this can be connected to any write path.
const crypto = require('node:crypto');
const OID = /^[0-9a-f]{40}$/;
const MUTATION = `mutation Apply($input: CreateCommitOnBranchInput!) {
  createCommitOnBranch(input: $input) {
    clientMutationId
    commit { oid parents(first: 2) { totalCount nodes { oid } } }
  }
}`;
function reject(message) { const e = new Error(message); e.notSent = true; throw e; }
function digest(s) { return crypto.createHash('sha256').update(s, 'utf8').digest('hex'); }

// Dependencies are NOT production implementations. `authorize` MUST verify a
// trusted single-use audit bound to the exact proposed bytes and baseline.
// `journal.reserve` MUST be durable and cross-writer atomic, as must its lock;
// `sendOnce` MUST never retry; `verifyCommit` MUST independently inspect exact
// parent, full tree delta, modes and file bytes at the immutable commit SHA.
async function writeWholeHead(input, deps) {
  const {repository, branch, filename, content, message, base, mode, audit} = input;
  if (repository !== 'Maka-opsol/Automa-bot' || branch !== 'main' ||
      typeof filename !== 'string' || !/^[A-Za-z0-9_./-]+$/.test(filename) ||
      filename.split('/').some(x => !x || x === '.' || x === '..' || x.startsWith('.')) ||
      typeof content !== 'string' || typeof message !== 'string' || !OID.test(base || '') ||
      mode !== '100644' || !audit) reject('Invalid or unsupported write input');
  if (!deps || !deps.journal || typeof deps.authorize !== 'function' ||
      typeof deps.sendOnce !== 'function' || typeof deps.verifyCommit !== 'function' ||
      typeof deps.enabled !== 'function') reject('Missing safety dependency');
  const payloadDigest = digest(content);
  const authorization = Object.freeze({ repository, branch, filename, contentDigest: payloadDigest, base });
  if (await deps.authorize(audit, authorization) !== true) reject('Audit authorization rejected');
  if (await deps.enabled() !== true) reject('Writes disabled');
  // Per-target marker must persist before any mutation leaves this process.
  const id = crypto.randomBytes(32).toString('hex');
  let reservation;
  try { reservation = await deps.journal.reserve({ ...authorization, operation: id }); }
  catch { reject('Journal reservation unavailable'); }
  if (!reservation || reservation.status !== 'reserved') reject('Journal reservation unavailable');
  // Deliberately keep reservation even if the switch changes. A crash at any
  // point after reserve is conservatively reconciled, never retried here.
  if (await deps.enabled() !== true) reject('Writes disabled after reservation');
  const request = { query: MUTATION, variables: { input: {
    branch: { repositoryNameWithOwner: repository, branchName: branch },
    expectedHeadOid: base,
    message: { headline: message },
    fileChanges: { additions: [{ path: filename, contents: Buffer.from(content, 'utf8').toString('base64') }] },
    clientMutationId: id
  } } };
  let result;
  try {
    result = await deps.sendOnce(request);
    const p = result && result.data && result.data.createCommitOnBranch;
    const c = p && p.commit;
    if (!result || result.status !== 200 || (result.errors !== undefined && (!Array.isArray(result.errors) || result.errors.length !== 0)) ||
        !p || p.clientMutationId !== id || !c || !OID.test(c.oid || '') ||
        c.parents?.totalCount !== 1 || c.parents?.nodes?.length !== 1 || c.parents.nodes[0].oid !== base) {
      throw new Error('Unconfirmed mutation response');
    }
    if (await deps.verifyCommit({ ...authorization, mode, commit: c.oid, content }) !== true)
      throw new Error('Immutable commit verification failed');
    if (await deps.journal.committed(reservation, c.oid) !== true)
      throw new Error('Journal completion not confirmed');
    return c.oid;
  } catch (cause) {
    try { await deps.journal.uncertain(reservation); } catch {}
    // No response, error class, current HEAD, or identical content is proof
    // that the operation did not happen. No automatic replay or rebase.
    throw new Error('Write outcome or journal completion unknown; reconciliation required');
  }
}
module.exports = { writeWholeHead, MUTATION };

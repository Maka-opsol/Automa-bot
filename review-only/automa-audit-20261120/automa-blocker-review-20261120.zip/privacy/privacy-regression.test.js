'use strict';
const {test}=require('node:test'), assert=require('node:assert/strict'), fs=require('node:fs'), os=require('node:os'), path=require('node:path'), crypto=require('node:crypto'), vm=require('node:vm'), zlib=require('node:zlib');
const {audit,unzip,crc32,request}=require('./actions-auditor');
const source=fs.readFileSync(path.join(__dirname,'app.js'),'utf8'), strict=vm.runInNewContext('('+source.slice(source.indexOf('function _strictJson('),source.indexOf('\nfunction _aiProviders()'))+')');
const sha=x=>crypto.createHash('sha256').update(x).digest('hex'), base='const sample = 1;\n', candidate='const sample = 2;\n', blob=crypto.createHash('sha1').update('blob '+Buffer.byteLength(base)+'\0'+base).digest('hex'), commit='a'.repeat(40), nonce='1'.repeat(64);
function zip(data,{name='dashboard-audit-verdict.json',method=8,descriptor=false}={}){
 data=Buffer.from(data);let n=Buffer.from(name), c=method===8?zlib.deflateRawSync(data):data,crc=crc32(data), flags=descriptor?8:0;
 let l=Buffer.alloc(30);l.writeUInt32LE(0x04034b50);l.writeUInt16LE(20,4);l.writeUInt16LE(flags,6);l.writeUInt16LE(method,8);if(!descriptor){l.writeUInt32LE(crc,14);l.writeUInt32LE(c.length,18);l.writeUInt32LE(data.length,22)}l.writeUInt16LE(n.length,26);
 let d=Buffer.alloc(descriptor?16:0);if(descriptor){d.writeUInt32LE(0x08074b50);d.writeUInt32LE(crc,4);d.writeUInt32LE(c.length,8);d.writeUInt32LE(data.length,12)}
 let h=Buffer.alloc(46);h.writeUInt32LE(0x02014b50);h.writeUInt16LE(20,4);h.writeUInt16LE(20,6);h.writeUInt16LE(flags,8);h.writeUInt16LE(method,10);h.writeUInt32LE(crc,16);h.writeUInt32LE(c.length,20);h.writeUInt32LE(data.length,24);h.writeUInt16LE(n.length,28);
 let cd=Buffer.concat([h,n]), e=Buffer.alloc(22);e.writeUInt32LE(0x06054b50);e.writeUInt16LE(1,8);e.writeUInt16LE(1,10);e.writeUInt32LE(cd.length,12);e.writeUInt32LE(l.length+n.length+c.length+d.length,16);return Buffer.concat([l,n,c,d,cd,e]);
}
function setup(opts={}) {
 const base=opts.base ?? 'const sample = 1;\n', candidate=opts.candidate ?? 'const sample = 2;\n', blob=crypto.createHash('sha1').update('blob '+Buffer.byteLength(base)+'\0'+base).digest('hex');
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'actions-review-'));fs.chmodSync(dir,0o700);const admission=path.join(dir,'public.json');fs.writeFileSync(admission,JSON.stringify({version:1,entries:[{path:'src/file.ts',baseline_sha256:sha(base),candidate_sha256:sha(candidate)}]}),{mode:0o600});
 const skipAdmission=opts.skipAdmission===true;
 const env={ACTIONS_AUDIT_PREREQUISITES:skipAdmission?'operator-opted-skip-admission':'reviewed-private-admission-and-durable-journal',ACTIONS_AUDIT_TOKEN:'synthetic-SECRET-key',ACTIONS_AUDIT_WORKFLOW_ID:'37',ACTIONS_AUDIT_ACTOR_ID:'15',ACTIONS_AUDIT_REPOSITORY_ID:'20',ACTIONS_AUDIT_WORKFLOW_SHA:commit,ACTIONS_AUDIT_ARTIFACT_HOST:'storage.example.test',ACTIONS_AUDIT_JOURNAL_DIR:dir,...(skipAdmission?{ACTIONS_AUDIT_SKIP_ADMISSION:'1'}:{ACTIONS_AUDIT_ADMISSION_FILE:admission}),ACTIONS_AUDIT_TIMEOUT_MS:'5000',ACTIONS_AUDIT_POLL_MS:'250',...opts.env};
 const run={id:9,workflow_id:37,event:'workflow_dispatch',head_branch:'main',head_sha:commit,run_attempt:1,repository:{id:20,full_name:'Maka-opsol/Automa-bot'},head_repository:{id:20},actor:{id:15},triggering_actor:{id:15},status:'completed',conclusion:'success'};
 const verdict={version:1,nonce,path:'src/file.ts',base_blob:blob,candidate_sha256:sha(candidate),run_id:'9',run_attempt:1,job:'audit',workflow_sha:commit,providers:['ollama#security','ollama#correctness','ollama#intent'],safe:true};const calls=[];
 async function transport(url,p){calls.push({url,...p});let data,status=200,location=null;
  if(url.endsWith('/workflows/37')||url.endsWith('/workflows/dashboard-auditor.yml'))data={id:37,path:'.github/workflows/dashboard-auditor.yml',state:'active'};
  else if(url==='https://api.github.com/user')data={id:15};
  else if(url==='https://api.github.com/repos/Maka-opsol/Automa-bot')data={id:20};
  else if(url.endsWith('/branches/main'))data={commit:{sha:commit}};
  else if(url.endsWith('/dispatches')){assert.equal(p.method,'POST');assert.equal(p.body.return_run_details,true);assert.equal(p.body.ref,'main');assert.equal(p.body.inputs.nonce,nonce);data={workflow_run_id:9};if(opts.dispatch)({status=200,data}=opts.dispatch);}
  else if(url.endsWith('/actions/runs/9')){const count=calls.filter(x=>x.url.endsWith('/actions/runs/9')).length;data={...run,...opts.run,...(opts.runSequence?.[Math.min(count-1,opts.runSequence.length-1)]||{})};}
  else if(url.includes('/attempts/1/jobs'))data=opts.jobs||{total_count:1,jobs:[{name:'audit',run_id:9,run_attempt:1,status:'completed',conclusion:'success'}]};
  else if(url.includes('/actions/runs/9/artifacts'))data=opts.artifacts||{total_count:1,artifacts:[{id:55,name:'audit-'+nonce,expired:false,size_in_bytes:500,workflow_run:{id:9,repository_id:20,head_sha:commit}}]};
  else if(url.endsWith('/actions/artifacts/55/zip')){status=302;location=opts.redirect||'https://storage.example.test/signed?signature=hidden';data='';}
  else if(!url.startsWith('https://api.github.com/')){assert.equal(p.token,undefined);data=opts.archive||zip(opts.rawVerdict||JSON.stringify({...verdict,...opts.verdict}));}
  else throw Error('unexpected URL');
  return {status,location,data:Buffer.isBuffer(data)?data:Buffer.from(typeof data==='string'?data:JSON.stringify(data))};
 }
 const go=(p=candidate,ctx={reviewedSha:blob,originalContent:base})=>audit(p,'src/file.ts','test',false,'tester',ctx,{env,strictJson:strict,transport,randomBytes:()=>Buffer.from(nonce,'hex'),sleep:async()=>{}});
 return {dir,env,calls,go,transport,close:()=>fs.rmSync(dir,{recursive:true,force:true})};
}
test('exact admitted candidate and three bound providers pass mock audit',async()=>{const h=setup();try{assert.equal((await h.go()).safe,true);assert.equal(h.calls.filter(c=>c.method==='POST').length,1);assert.equal((await h.go()).safe,false);}finally{h.close()}});
test('missing trusted workflow pin fails before network',async()=>{const h=setup({env:{ACTIONS_AUDIT_WORKFLOW_SHA:undefined}});try{assert.equal((await h.go()).safe,false);assert.equal(h.calls.length,0)}finally{h.close()}});
for(const providers of [[],['x','y'],['ollama#security','ollama#correctness'],['ollama#security','ollama#correctness','fake'],['ollama#security','ollama#security','ollama#intent'],['ollama#security','ollama#correctness','ollama#intent','other']]) test('rejects incomplete or wrong quorum '+JSON.stringify(providers),async()=>{const h=setup({verdict:{providers}});try{assert.equal((await h.go()).safe,false)}finally{h.close()}});
test('rejects run from wrong workflow commit',async()=>{const h=setup({run:{head_sha:'b'.repeat(40)}});try{assert.equal((await h.go()).safe,false)}finally{h.close()}});
test('unadmitted and denied candidates fail before network',async()=>{for(const p of ['const sample = 3;\n','const password = 4;\n','a'.repeat(4097)]){const h=setup();try{assert.equal((await h.go(p)).safe,false);assert.equal(h.calls.length,0)}finally{h.close()}}});
test('oversized README fails before network',async()=>{const h=setup();try{const b='A'.repeat(4096)+'\n',p=b+'More.\n',hash=crypto.createHash('sha1').update('blob '+Buffer.byteLength(b)+'\0'+b).digest('hex');let n=0;const r=await audit(p,'README.md','test',false,'tester',{publicReadme:true,reviewedSha:hash,originalContent:b},{env:h.env,strictJson:strict,transport:async()=>{n++;throw Error('network forbidden')}});assert.equal(r.safe,false);assert.equal(n,0)}finally{h.close()}});
